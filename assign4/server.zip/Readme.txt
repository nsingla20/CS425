First run server.py then client.py, otherwise it may hang.
